import 'package:flutter/material.dart';
import 'screens/role_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const RideNowApp());
}

class RideNowApp extends StatelessWidget {
  const RideNowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RideNow',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const RoleScreen(),
    );
  }
}
