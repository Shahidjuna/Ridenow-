import 'package:flutter/material.dart';
import 'passenger_home.dart';
import 'driver_home.dart';
import 'admin_home.dart';

class RoleScreen extends StatelessWidget {
  const RoleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.local_taxi, size: 80, color: Colors.blue),
              const SizedBox(height: 16),
              const Text('RideNow', style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
              const Text('Your ride, your way', style: TextStyle(fontSize: 16)),
              const SizedBox(height: 40),
              _button(context, 'Passenger', Icons.person, const PassengerHome()),
              const SizedBox(height: 14),
              _button(context, 'Driver', Icons.drive_eta, const DriverHome()),
              const SizedBox(height: 14),
              _button(context, 'Admin', Icons.admin_panel_settings, const AdminHome()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _button(BuildContext context, String title, IconData icon, Widget page) {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton.icon(
        icon: Icon(icon),
        label: Text(title),
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
      ),
    );
  }
}
