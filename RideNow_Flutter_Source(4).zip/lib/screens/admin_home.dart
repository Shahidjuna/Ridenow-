import 'package:flutter/material.dart';

class AdminHome extends StatelessWidget {
  const AdminHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('RideNow • Admin')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: const [
          Card(child: ListTile(leading: Icon(Icons.people), title: Text('Users'), subtitle: Text('Manage passengers and drivers'))),
          Card(child: ListTile(leading: Icon(Icons.directions_car), title: Text('Drivers'), subtitle: Text('KYC and approval workflow'))),
          Card(child: ListTile(leading: Icon(Icons.route), title: Text('Rides'), subtitle: Text('Monitor active and completed rides'))),
          Card(child: ListTile(leading: Icon(Icons.payments), title: Text('Commission'), subtitle: Text('Configure platform commission'))),
        ],
      ),
    );
  }
}
