import 'package:flutter/material.dart';

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  bool online = false;
  String status = 'You are offline';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('RideNow • Driver')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: SwitchListTile(
              title: Text(online ? 'You are Online' : 'You are Offline'),
              subtitle: const Text('Receive nearby ride requests'),
              value: online,
              onChanged: (v) => setState(() {
                online = v;
                status = v ? 'Waiting for ride requests...' : 'You are offline';
              }),
            ),
          ),
          const SizedBox(height: 16),
          Card(child: ListTile(leading: const Icon(Icons.account_balance_wallet), title: const Text('Today\'s earnings'), subtitle: const Text('PKR 0'))),
          const SizedBox(height: 16),
          Card(child: ListTile(leading: const Icon(Icons.notifications_active), title: const Text('Ride requests'), subtitle: Text(status))),
          const SizedBox(height: 20),
          if (online)
            FilledButton.icon(
              icon: const Icon(Icons.local_taxi),
              label: const Text('Simulate Ride Request'),
              onPressed: () => showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('New Ride Request'),
                  content: const Text('Passenger: Demo User\nPickup: Gulshan-e-Iqbal\nDestination: Bahadurabad\nOffer: PKR 500'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Reject')),
                    FilledButton(onPressed: () { Navigator.pop(context); setState(() => status = 'Ride accepted'); }, child: const Text('Accept')),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
