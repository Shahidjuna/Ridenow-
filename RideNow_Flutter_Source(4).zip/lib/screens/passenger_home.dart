import 'package:flutter/material.dart';
import '../services/location_service.dart';

class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});
  @override
  State<PassengerHome> createState() => _PassengerHomeState();
}

class _PassengerHomeState extends State<PassengerHome> {
  final pickup = TextEditingController();
  final destination = TextEditingController();
  final fare = TextEditingController(text: '500');
  String status = 'Ready to book';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('RideNow • Passenger')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Where are you going?', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          TextField(controller: pickup, decoration: const InputDecoration(labelText: 'Pickup', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: destination, decoration: const InputDecoration(labelText: 'Destination', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: fare, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Your fare offer (PKR)', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            icon: const Icon(Icons.my_location),
            label: const Text('Use my current location'),
            onPressed: () async {
              final p = await LocationService.currentLocation();
              setState(() => status = p == null ? 'Location permission/location unavailable' : 'Current location received');
            },
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: () {
              if (pickup.text.isEmpty || destination.text.isEmpty) {
                setState(() => status = 'Pickup and destination required');
                return;
              }
              setState(() => status = 'Searching for nearby drivers...');
            },
            child: const Text('Find Driver'),
          ),
          const SizedBox(height: 24),
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(status))),
          const SizedBox(height: 18),
          const Card(
            child: ListTile(
              leading: Icon(Icons.info_outline),
              title: Text('Next production step'),
              subtitle: Text('Connect this screen to Firebase rides and real-time driver offers.'),
            ),
          ),
        ],
      ),
    );
  }
}
