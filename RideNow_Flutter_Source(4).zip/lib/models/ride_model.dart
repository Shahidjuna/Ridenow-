class RideModel {
  final String id;
  final String passengerId;
  final String? driverId;
  final String pickup;
  final String destination;
  final int offeredFare;
  final String status;

  RideModel({
    required this.id,
    required this.passengerId,
    this.driverId,
    required this.pickup,
    required this.destination,
    required this.offeredFare,
    required this.status,
  });

  Map<String, dynamic> toMap() => {
    'passengerId': passengerId,
    'driverId': driverId,
    'pickup': pickup,
    'destination': destination,
    'offeredFare': offeredFare,
    'status': status,
  };
}
