import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseService {
  final FirebaseFirestore db = FirebaseFirestore.instance;

  Future<DocumentReference<Map<String, dynamic>>> createRide(Map<String, dynamic> ride) {
    return db.collection('rides').add({
      ...ride,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
